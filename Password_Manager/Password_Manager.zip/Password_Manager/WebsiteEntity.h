#pragma once
#include <string>

struct WebsiteEntity
{
	std::string username;
	std::string password;
};

